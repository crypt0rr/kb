Explorer++ 1.3.5 32-bit
-----------------------

Copyright (c) 2005-2011 David Erceg

Explorer++ is free software released under
the GNU General Public License.

www.explorerplusplus.com


About Explorer++
----------------
Explorer++ is a free multi-tab file manager for Windows.
Available on Windows XP and above, it features the
same familiar interface as Windows Explorer, while
introducing several enhancements and improvements for a
much richer file browsing experience.


Using Explorer++
----------------
Explorer++ can simply be extracted and run.
There is no need to install it.


Reporting Problems
------------------
Please send any bugs or problems to:

david@explorerplusplus.com