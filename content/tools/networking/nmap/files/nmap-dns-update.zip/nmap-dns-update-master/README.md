# nmap dns-update

This repository contains 2 .nse scripts, based off of the original "dns-update.nse" provided with nmap.
The 2 scripts seperate the adding and deleting of the injected DNS record, so it can be manually verified (or used) rather than trusting nmap.

Commandline options stay the same. Example: nmap -sU -p 53 --script=dns-update --script-args=dns-update.hostname=foo.example.com,dns-update.ip=192.0.2.1 <target>